/* ========================================
 *
 *  Stepper.h
 *
 *  Created: 13-09-2017 22:42:53
 *  Author: Andreas Hervert Nielsen
 * 
 * ========================================
 */

#include "project.h"
#include <stdio.h>
#include <CyLib.h>
#include <stdlib.h>
#include <cydevice.h>//så kan den bedre li at sende

#include "getDistance.h" //Mortens beregning bib
//#include "I2C_sensor.h" //Andreas I2C til ultralyd sensor bib


void afstand();



float ultraEcho();

void ultraDelay();

void ultraTrigger();




//TIL I2C sensor

#define initiateSensor 0b11100000
#define writeRange 0b01010001
#define readRange 0b11100001

#define slave_rx 0xE0
#define slave_tx 0x51


//Til I2C sensor
uint8 bufferRx1;
uint8 bufferRx2;
uint8 bufferTx1;
uint8 bufferTx2;
char f[36];
uint8 x =0;

uint8 statusI2C = 0;
float message = 0;



//Til arduino sensoren
uint16 counts = 0; 
float  feet   = 0; 
uint16 i      = 0; 



int motor = 0;
int drej = 0;
float distance = 0;


char f[36];


CY_ISR(UART_1_Rx_Handler)
{
    uint8_t received = UART_1_ReadRxData();
    UART_1_WriteTxData(received);
    
        
    if (received == 'a')
    {
        UART_1_PutString("\n Drejer til venstre \r \n");
        drej = 1;
       
    }
    else if (received == 'd')
    {
        UART_1_PutString("\n Drejer til hoejre \r \n");
       drej = 2;
    }  
    else if (received == 'w')
    {
        UART_1_PutString("\n Fremad \r \n");
        motor = 1;
        
        
    }
    else if (received == 'x')
    {
        UART_1_PutString("\n Tilbage af \r \n");
        motor = 2;
        
    }
    else if (received == 's')
    {
        UART_1_PutString("\nMotor Stoppet \r \n");
        motor = 0;
    }
    else if (received == 'z')
    {
        UART_1_PutString("\n \r \n");
        
        CyDelay(250);
         LED_Write(1);
        
        afstand();
        snprintf(f, sizeof(f),"verdi:  %f \r\n", distance);
        UART_1_PutString(f);
        CyDelay(250);
        LED_Write(0);
    }
    else
    {
        UART_1_PutString("\n \n \nHELP1: Du kan brug 1 til 9 og 0 for hastigheder. \r \n"); 
        UART_1_PutString("HELP2: Q og E og W for half, full og wave mode. \r \n");
        UART_1_PutString("HELP3: z for at tage en enkel omgang. \r \n");
        UART_1_PutString("HELP4: A og D er for fremad og bakgear. \r \n \n \n");
    }
}    



int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    I2C_1_Start();
    isr_UART_1_RX_StartEx(UART_1_Rx_Handler);
    UART_1_Start();
    UART_1_PutString("Application started\r\n");
    Counter_Start();
    
    LED_Write(0);
    VCC_Write(1); 
    
    
    for(;;)
    {
       // while(0 == Ekko_Read())
       // {
            
        //}
        
        CyDelay(500);
        
        Trigger_Write(1);
        
        ultraDelay();
        
        
        Trigger_Write(0);
        
        //ultraTrigger();
        
        float test = ultraEcho();
        
        Trigger_Write(0);
        
        snprintf(f, sizeof(f),"test modtager afstand:  %f \r\n", test);
        UART_1_PutString(f);

           
           
            
    }
}




/* [] END OF FILE */




void ultraDelay()
{
    statusI2C = I2C_1_MasterSendStart(slave_tx, 0); //kontroler om slaven lm75 er klar til at komminuker
    
    
    if(statusI2C == I2C_1_MSTR_NO_ERROR)
    {
        I2C_1_MasterWriteByte(initiateSensor); 
    }
}


void ultraTrigger()
{
    statusI2C = I2C_1_MasterSendStart(slave_tx, 0); //kontroler om slaven lm75 er klar til at komminuker

    if(statusI2C == I2C_1_MSTR_NO_ERROR)
    {
        I2C_1_MasterWriteByte(writeRange); 
    }     
 }



float ultraEcho()
{
    float distance = 0;
    float distance2 = 0;
    statusI2C = I2C_1_MasterSendStart(slave_rx, 1); //kontroler om slaven lm75 er klar til at komminuker
        
        
        //kvis I2C er klar  til at komminuker
        if (statusI2C == I2C_1_MSTR_NO_ERROR)
        {
            bufferRx1 = I2C_1_MasterReadByte(I2C_1_ACK_DATA);  //Modtager de 
            bufferRx2 = I2C_1_MasterReadByte(I2C_1_NAK_DATA);
            
            I2C_1_MasterSendStop();     //fortæller slave at den skal stoppe med at sende information
             
            if(bufferRx1 == slave_rx )      //Initiate a write at the sensor address 
            {
                message = bufferRx2;               //Beskeden bliver overført fra buffer. 
                //UART_1_PutString("Temp: ");
                //writeTempToUART(temp);            //Sender temp
            }
            else
            {
                message = bufferRx1;
                //UART_1_PutString("Temp: ");
                //writeTempToUART(temp);             //Sender temp uden halve grader
            }
                
            distance = message;
            
                   
            CyDelay(50);
            
            bufferRx1 = I2C_1_MasterReadByte(I2C_1_ACK_DATA);  //Modtager de 
            bufferRx2 = I2C_1_MasterReadByte(I2C_1_NAK_DATA);
            
            if(bufferRx1 == slave_rx )      //Initiate a write at the sensor address 
            {
                message = bufferRx2;               //Beskeden bliver overført fra buffer. 
                //UART_1_PutString("Temp: ");
                //writeTempToUART(temp);            //Sender temp
            }
            else
            {
                message = bufferRx1;
                //UART_1_PutString("Temp: ");
                //writeTempToUART(temp);             //Sender temp uden halve grader
            }
            
            distance2 = message;
            //distance = (bufferRx2[0] * 256 + bufferRx2[1] * 512 + bufferRx2[2] * 1024 + bufferRx2[3] * 2048 + bufferRx2[4] * 4096 + bufferRx2[5] * 8192 + bufferRx2[6] * 16384 + bufferRx2[7] * 32768 + bufferRx2[8] * 65536) + distance;
            
        }
         else
        {                                                  //kvis I2C ikke er klar  til at komminuker
            UART_1_PutString("virker ikke\r\n");
            I2C_1_MasterSendStop();                             // fortæller slaven at kommukitationen er slut
        }
    
        snprintf(f, sizeof(f),"verdi1:  %f \r\n", distance);
        UART_1_PutString(f);
        
            snprintf(f, sizeof(f),"verdi2:  %f \r\n", distance2);
        UART_1_PutString(f);
        
    
    return distance;
}




void afstand()
  {
	    uint16 counts = 0; // value to store results from the counter
        float  feet = 0; 
 
        Enable_Write(0); 
        Sonic_Sensor_Write(1);   //Output the sensor pulse 


        CyDelayUs(10); //wait for the sensor pulse to finish 


        Sonic_Sensor_Write(0); //shut off the sensor pulse
        Enable_Write(1); 
 
        Sonic_Sensor_Read(); //receive return pulse 

        CyDelay(50); // wait for the maximum value of the return pulse 

        counts = Counter_ReadCounter();// read counter value 

        feet = counts * 0.0001717; //convert pulse width to feet, to convert to meters, multiply by 0.0001717 instead. 

        CyDelayUs(10);

        if (feet < 1.0 ) 
            { 
               
                LED_Write(1); 
                 
                
            } 
             
             else 
            { 
          
                LED_Write(0); 
             }  
                
              Enable_Write(0);// reset the counter 


	 
  }