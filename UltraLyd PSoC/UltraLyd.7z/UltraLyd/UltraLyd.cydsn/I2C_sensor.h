/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include <stdio.h>
#include <CyLib.h>
#include <stdlib.h>
#include <cydevice.h>//så kan den bedre li at sende


//float ultraEcho();

//void ultraDelay();

//void ultraTrigger();