using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

using System.Text; //Bennyttes til decodning Encoding.ASCII.GetBytes

namespace tcp
{
	class file_client
	{
		/// <summary>
		/// The PORT.
		/// </summary>
		const int PORT = 9000;
		/// <summary>
		/// The BUFSIZE.
		/// </summary>
		const int BUFSIZE = 1000;

		/// <summary>
		/// Initializes a new instance of the <see cref="file_client"/> class.
		/// </summary>
		/// <param name='args'>
		/// The command-line arguments. First ip-adress of the server. Second the filename
		/// </param>



		private file_client (string[] args)
		{
			// TO DO Your own code

			Console.WriteLine("Client Started");
			Console.WriteLine("\n Write the ip, to server");
			string IP = Console.ReadLine();
			Console.WriteLine("\n Trying to connect to");
			Console.WriteLine(IP);

			try
			{
				IPAddress[] ipAddress = Dns.GetHostAddresses(IP);
				IPEndPoint ipEnd = new IPEndPoint(ipAddress[0], PORT);
				Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
				clientSock.Connect(ipEnd);
				Console.WriteLine("\n Connection succes");

				//Mulligher
				Console.WriteLine("\n Asking server for file...");
				byte[] bytes = new byte[BUFSIZE]; 
				int bytesRec = clientSock.Receive (bytes);  
				Console.WriteLine ("Mullige valg = {0}", Encoding.ASCII.GetString (bytes, 0, bytesRec)); 

				//Du vælger
				Console.WriteLine("\n Write the file, to recive from server");
				string choice = Console.ReadLine();
				Console.WriteLine("\n you wrote");
				Console.WriteLine(choice);
				byte[] msg = Encoding.ASCII.GetBytes (choice); 
				clientSock.Send (msg); 

				receiveFile (clientSock, choice); //Starter modtagelse

				Console.WriteLine("\n Resume/overblik:");
				Console.WriteLine("Server:{0} connected & File {1}.", clientSock.RemoteEndPoint, choice);

				Console.WriteLine("\n Done lukker forbindelse");
				clientSock.Close();

			}
			catch 
			{
				Console.WriteLine("\n Noget gik galt, genstarter...");
			}
			//Lukker ned

		}

		/// <summary>
		/// Receives the file.
		/// </summary>
		/// <param name='fileName'>
		/// File name.
		/// </param>
		/// <param name='io'>
		/// Network stream for reading from the server
		/// </param>
		private void receiveFile (Socket clientSock, string fileName) //Har fjernet string name, da det kommer med filen
		{
			// TO DO Your own code

			//Går igang med at modtage filen
			byte[] clientData = new byte[BUFSIZE];
			string receivedPath = "/root/Desktop/Download/";

			byte[] fileNameByte = Encoding.ASCII.GetBytes(fileName);
			int fileNameLen = BitConverter.ToInt32(fileNameByte, 0);

			try
			{
				File.Delete(receivedPath + fileName);
				Console.WriteLine("\n Sletter filen før genskrivning");
			}
			catch 
			{
				Console.WriteLine("\n Opretter modtaget file");
			}

			Console.WriteLine("Venter på server...");
			clientSock.Receive(clientData);
			int numVal = BitConverter.ToInt32(clientData, 0);
			Console.WriteLine("Der skal modtages {0} antal gange", numVal);

			for(int i = 1; i <= numVal; i = i + 1)
			{
				Array.Clear(clientData, 0, BUFSIZE);
				clientSock.Send(clientData); //Fortæller serveren at clienten er klar
				//System.Threading.Thread.Sleep(2);//Lader serveren overfører sin data SLOW DOWN
				int receivedBytesLen = clientSock.Receive(clientData);

				Console.Clear();
				Console.WriteLine("Venter: {0} ud af {1}.", i, numVal);
				Console.WriteLine("\n File modtaget starter decodning...");
				Console.WriteLine("\n Filesize = {0} bytes", receivedBytesLen.ToString());

				BinaryWriter bWrite = new BinaryWriter(File.Open(receivedPath + fileName, FileMode.Append));

				if (i == numVal) 
				{
					Console.WriteLine ("\n Last tjekpoint...");

					int size = BitConverter.ToInt32(clientData, 0);		
					Console.WriteLine (size);

					Array.Clear(clientData, 0, BUFSIZE);
					clientSock.Send(clientData); //Fortæller serveren at clienten er klar
					clientSock.Receive(clientData);

					bWrite.Write (clientData, 1, size); //Samler filen
				} 
				else 
				{
					bWrite.Write(clientData, 1, clientData.Length - 1); //Samler filen
				}

				bWrite.Close(); //Færdiggør filen til en hel file
			}
		}

		/// <summary>
		/// The entry point of the program, where the program control starts and ends.
		/// </summary>
		/// <param name='args'>
		/// The command-line arguments.
		/// </param>
		public static void Main (string[] args)
		{
			while (true) 
			{
				Console.WriteLine ("Client starts...");
				new file_client (args); //Starter class
			}
		}
	}
}
